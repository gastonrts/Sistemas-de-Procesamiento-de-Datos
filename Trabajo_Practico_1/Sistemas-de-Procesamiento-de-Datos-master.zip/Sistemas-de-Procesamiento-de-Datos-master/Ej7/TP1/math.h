#include <stdio.h>
#include <stdlib.h>
#include "math.h" //para local "" y global <> #include stdio_ext.h>
#include <stdio_ext.h>
#include "math.h"
