#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero;
    int contador = 0;
    while (contador<5)
    {
        printf("Ingrese un numero:");
        scanf("%d",&numero);

        contador++;
    }


    return 0;
}
